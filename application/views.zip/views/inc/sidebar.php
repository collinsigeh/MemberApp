<a href="<?php echo base_url().'dashboard/profile/'; ?>">My Profile</a>
<hr>
<a href="<?php echo base_url().'dashboard/subscriptions/'; ?>">My Subscriptions</a>
<hr>
<a href="<?php echo base_url().'dashboard/resources/'; ?>">Resource Centre</a>
<hr>
<a href="<?php echo base_url().'dashboard/orders/'; ?>">Order History</a>
<hr>
<a href="<?php echo base_url().'dashboard/shop/'; ?>">Shop</a>
<hr>
<a href="<?php echo base_url().'dashboard/logout/'; ?>">Logout</a>