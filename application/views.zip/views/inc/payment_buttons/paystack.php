<form action="<?php echo base_url().'dashboard/paystack_payment/'.$order->id ; ?>" method="POST"> 

<button type="submit" name="pay_now" id="pay-now" title="Pay now" class="btn btn-sm btn-outline-primary">Pay now</button>

</form>