
                    <div class="form2-section">
                        <div class="form2-section-heading">Additional Contact Detail</div>
                        <div class="form2-section-body">

                            <div class="form-group">
                                <label for="home_address">Home Address</label>
                                <input class="form-control" type="text" name="home_address" id="home_address" value="<?php echo $this->session->home_address; ?>" required />
                            </div>

                        </div>
                    </div>

                    <!-- START TEMPORARILY REMOVED

                    <div class="form2-section">
                        <div class="form2-section-heading">Authorization status</div>
                        <div class="form2-section-body">

                            <div class="form-group">
                                <label for="ncaa_roc_number">NCAA Registration Number</label>
                                <input class="form-control" type="text" name="ncaa_roc_number" id="ncaa_roc_number" value="<?php // echo $this->session->ncaa_roc_number; ?>" required />
                                <span class="small text-muted">*** If not available, state your status ***</span>
                            </div>

                        </div>
                    </div>

                    END TEMPORARILY REMOVED -->