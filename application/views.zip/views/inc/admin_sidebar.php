<a href="<?php echo base_url().'dashboard/profile/'; ?>">My Profile</a>
<hr>
<a href="<?php echo base_url().'users'; ?>">User Accounts</a>
<hr>
<a href="<?php echo base_url().'member_resources/'; ?>">Member Resources</a>
<hr>
<a href="<?php echo base_url().'products/'; ?>">Products & Subscriptions</a>
<hr>
<a href="<?php echo base_url().'orders/'; ?>">Order Requests</a>
<hr>
<a href="<?php echo base_url().'payments/'; ?>">Payments</a>
<hr>
<a href="<?php echo base_url().'settings'; ?>">Settings</a>
<hr>
<a href="<?php echo base_url().'dashboard/logout/'; ?>">Logout</a>