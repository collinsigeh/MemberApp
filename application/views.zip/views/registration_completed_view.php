<!-- Page Content -->
<div class="container">
  <div class="page">
    <div class="row">
      <div class="col-md-10 offset-md-1">
        <div class="main-content">
          <!-- Main content -->
          <?php 
            $this->load->view('inc/action_message');
          ?>
          
          <div class="text-center">
            <a href="<?php echo base_url().'dashboard/login/'; ?>" class="custom-outline-button">Go to Login page</a>
          </div>
      </div>
    </div>
  </div>
</div>